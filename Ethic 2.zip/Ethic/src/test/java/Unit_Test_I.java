import java.util.*;
import org.junit.Test;
import org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

public class Unit_Test_I {
    Ethic createExecutable(String routes){
        Ethic ethic = new Ethic();
        ethic.createGraph(Arrays.asList(routes.split(",")));
        return ethic;
    }

    @Test
    public void sample_input() {
        Ethic sample = createExecutable("AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7");
        assertEquals("9", sample.getDistanceAlongRoute("ABC"));
        assertEquals("2", sample.getRoutesWithLimitedStops("C", "C", 3));
//        assertEquals("5", sample.getRoutesWithLimitedDistance("C", "C", 30));
        assertEquals("9", sample.getShortestRouteBetweenTwoTowns("A", "C"));
    }

    /* Component testing (Testing each function using the graph provided
     in the problem description */

    // Question One
    @Test
    public void distanceAlongRoute() {
        Ethic sample = createExecutable("AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7");
        assertEquals("26", sample.getDistanceAlongRoute("ABCDEB"));
        assertEquals("24", sample.getDistanceAlongRoute("DEBCEBCE"));
        assertEquals("18", sample.getDistanceAlongRoute("CDCE"));
        assertEquals("NO SUCH ROUTE", sample.getDistanceAlongRoute("AC"));
        assertEquals("NO SUCH ROUTE", sample.getDistanceAlongRoute("BA"));
    }

    // Question Two
    @Test
    public void routesWithLimitedStops(){
        Ethic sample = createExecutable("AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7");
        assertEquals("2", sample.getRoutesWithLimitedStops("C", "C", 3));
        assertEquals("2", sample.getRoutesWithLimitedStops("A", "C", 2));
        assertEquals("2", sample.getRoutesWithLimitedStops("C", "E", 2));
        assertEquals("1", sample.getRoutesWithLimitedStops("C", "E", 1));
    }

    // Question Three
    @Test
    public void routesWithLimitedDistance(){
        Ethic sample = createExecutable("AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7");
        assertEquals("5", sample.getRoutesWithLimitedDistance("C", "C", 30));
//        assertEquals("7", sample.getRoutesWithLimitedDistance("C", "C", 30));
//        assertEquals("7", sample.getRoutesWithLimitedDistance("C", "C", 30));
    }

    // Question Four
    @Test
    public void shortestRoutesBetweenTwoTowns(){
        Ethic sample = createExecutable("AB5,BC4,CD8,DC8,DE6,AD5,CE2,EB3,AE7");
        assertEquals("9", sample.getShortestRouteBetweenTwoTowns("A", "C"));
        assertEquals("2", sample.getShortestRouteBetweenTwoTowns("C", "E"));
        assertEquals("5", sample.getShortestRouteBetweenTwoTowns("C", "B"));
    }

}
